// rates-api.js (Express版・PG・自己署名SSL許可の開発設定)
// エンドポイント：
//  GET  /api/rates?year=YYYY&mode=avg|ttm&symbols=USD,ETH
//  GET  /api/dashboard/summary?month=YYYY-MM&mode=avg
//  GET  /api/dashboard/monthly?year=YYYY&mode=avg
//  GET  /api/manual-entry?month=YYYY-MM&segment=total|corporate|personal&currency=ALL|USD&exclude_transfer=true
//  POST /api/csv-import              (multipart/form-data, field: file)
//  POST /api/csv-import/commit       (staging → app.manual_entry へ反映)
//  POST /api/manual-entry            手入力1件保存（CSVレート優先・月平均補完・JPY換算）
//  POST /admin/rates/sync[?month=YYYY-MM]  全通貨（月単位）同期（法定=exchangerate.host、暗号=CoinGecko）
//
// ＊本ファイルは「現状DBに存在する全通貨」を動的に判定し、同期対象を自動生成します
//   - 法定通貨: fx_rate_monthly に JPY/1通貨 の月平均を保存（base=JPYのtimeseriesを逆数化）
//   - 暗号通貨: crypto_usd_monthly に USD月平均を保存（JPY化は利用側で ×USD/JPY）
//   - ペッグUSD(USDT/USDC): 保存不要（常にUSDと同値で換算）
//   - 別名正規化: WBTC/XBT→BTC、NT$/NTD→TWD、円/YEN/JPN→JPY

import crypto from "crypto";
import dotenv from "dotenv";
dotenv.config();

// dev only: self-signed を許可
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

// ★ DATABASE_URL を 1 回だけ正規化（スキーム統一＋特殊文字エスケープ＋安全ログ）
if (process.env.DATABASE_URL) {
  let url = process.env.DATABASE_URL.trim();
  // postgresql:// → postgres:// に統一
  url = url.replace(/^postgresql:\/\//i, "postgres://");
  // # と ! を URL エンコード（未エスケープで来た場合の保険）
  if (url.includes("#") || url.includes("!")) {
    url = url.replace(/#/g, "%23").replace(/!/g, "%21");
  }
  process.env.DATABASE_URL = url;

  // マスクして表示（パスワードは出さない）
  try {
    const u = new URL(url);
    const masked =
      `${u.protocol}//${u.username}:${"*".repeat(8)}@${u.hostname}:${u.port}${u.pathname}${u.search || ""}`;
    console.log("DATABASE_URL normalized:", masked);
  } catch {
    console.log("DATABASE_URL normalized.");
  }
}

import cors from "cors";
import express from "express";
import pg from "pg";
import multer from "multer";
import { parse } from "csv-parse/sync";
import cron from "node-cron";
import fetch from "node-fetch";

const { Pool } = pg;
const { DATABASE_URL = "", PORT = 3001 } = process.env;

const BUILD_TAG = "manual-entry-debug-v2";

console.log("DEBUG DATABASE_URL =", DATABASE_URL);
if (!DATABASE_URL) {
  console.error("ERROR: DATABASE_URL が未設定です");
  process.exit(1);
}

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

const app = express();
app.use(
  cors({
    origin: ["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:5174"],
    methods: ["GET", "POST", "PUT", "OPTIONS"],
    allowedHeaders: ["Content-Type"],
    optionsSuccessStatus: 204,
  })
);
// （Express v5対応）正規表現でプリフライトを許可
app.options(/.*/, cors());
app.use(express.json());
app.use((req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  next();
});

/* =========================
 * 共通ユーティリティ
 * ========================= */
const normalizeCode = (code) => {
  const s = (code || "").toString().trim().toUpperCase();
  if (!s) return null;
  if (["円", "YEN", "JPN", "JPY"].includes(s)) return "JPY";
  if (["NT$", "NTD", "TWD"].includes(s)) return "TWD";
  if (["WBTC", "XBT"].includes(s)) return "BTC";
  return s;
};

const avg = (arr) => {
  if (!arr || arr.length === 0) return null;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
};

function monthRange(ym) {
  const [y, m] = ym.split("-").map(Number);
  const start = new Date(Date.UTC(y, m - 1, 1));
  const end = new Date(Date.UTC(y, m, 0));
  return { start, end };
}

/**
 * DB から “現状使われている通貨” を動的列挙
 * - currency_master があれば type を優先（crypto / pegged_usd / fiat）
 * - 無ければ実データからヒューリスティック（BTC/ETH→crypto、USDT/USDC→pegged、それ以外はfiat。JPYは対象外）
 */
async function getCurrencyUniverse() {
  const client = await pool.connect();
  try {
    const fiat = new Set();
    const cryptoSet = new Set();
    const pegged = new Set();

    // 1) マスタがあれば優先
    try {
      const { rows } = await client.query(`
        SELECT UPPER(code) AS code, LOWER(type) AS type, COALESCE(enabled,true) AS enabled
        FROM app.currency_master
      `);
      if (rows?.length) {
        for (const r of rows) {
          if (!r.enabled) continue;
          const c = normalizeCode(r.code);
          if (!c || c === "JPY") continue;
          if (r.type === "crypto") cryptoSet.add(c);
          else if (r.type === "pegged_usd") pegged.add(c);
          else fiat.add(c);
        }
      }
    } catch {
      /* 無ければ次へ */
    }

    // 2) 実データから補完（不足分のみ）
    const { rows: used } = await client.query(`
      WITH raw AS (
        SELECT UPPER(TRIM(currency)) cur FROM app.manual_entry
        UNION ALL SELECT UPPER(TRIM(currency)) FROM app.fx_rate_monthly
        UNION ALL SELECT UPPER(TRIM(symbol))   FROM app.crypto_usd_monthly
      )
      SELECT DISTINCT cur FROM raw WHERE cur IS NOT NULL AND cur <> ''
    `);

    for (const r of used) {
      const c = normalizeCode(r.cur);
      if (!c || c === "JPY") continue;
      if (fiat.has(c) || cryptoSet.has(c) || pegged.has(c)) continue;
      if (["BTC", "ETH"].includes(c)) {
        cryptoSet.add(c);
      } else if (["USDT", "USDC"].includes(c)) {
        pegged.add(c);
      } else {
        fiat.add(c);
      }
    }

    return {
      fiat: Array.from(fiat).sort(), // 法定（JPY除く）
      crypto: Array.from(cryptoSet).sort(), // 暗号（BTC/ETHほか）
      pegged_usd: Array.from(pegged).sort(), // USDT/USDC
    };
  } finally {
    client.release();
  }
}

/* =========================
 * /api/rates （表示用：tableを返す）
 * ========================= */
// ヘルスチェック（疎通確認・監視用）
app.get('/healthz', (req, res) => res.json({ ok: true, tag: BUILD_TAG }));
app.get("/api/rates", async (req, res) => {
  try {
    const year = String(req.query.year || "2025");
    const mode = String(req.query.mode || "avg"); // 'avg' | 'ttm'
    const symbols = String(req.query.symbols || "USD")
      .split(",")
      .map((s) => s.trim().toUpperCase())
      .filter(Boolean);

    const client = await pool.connect();
    try {
      const table = {};

      // --- 法定通貨（fx_rate_monthly） ---
      for (const symbol of symbols) {
        const { rows } = await client.query(
          `SELECT to_char(month_start,'YYYY-MM') AS ym, rate_month_avg, rate_ttm
             FROM app.fx_rate_monthly
            WHERE currency = $1
              AND month_start BETWEEN $2::date AND $3::date
            ORDER BY month_start`,
          [symbol, `${year}-01-01`, `${year}-12-31`]
        );
        for (const r of rows) {
          const ym = r.ym;
          table[ym] ||= {};
          table[ym][symbol] =
            mode === "ttm" ? Number(r.rate_ttm) : Number(r.rate_month_avg);
        }
      }

      // --- USD/JPY 月平均テーブル（USD→JPY換算に使用） ---
      const usdMap = {};
      const { rows: usdRows } = await client.query(
        `SELECT to_char(month_start,'YYYY-MM') AS ym, rate_month_avg, rate_ttm
           FROM app.fx_rate_monthly
          WHERE currency = 'USD'
            AND month_start BETWEEN $1::date AND $2::date
          ORDER BY month_start`,
        [`${year}-01-01`, `${year}-12-31`]
      );
      for (const r of usdRows) {
        usdMap[r.ym] =
          mode === "ttm" ? Number(r.rate_ttm) : Number(r.rate_month_avg);
      }

      // --- 暗号通貨：BTC/ETH（crypto_usd_monthly × USD/JPY） ---
      const cryptoSymbols = symbols
        .map((s) => s.toUpperCase())
        .filter((s) => s === "BTC" || s === "ETH");

      if (cryptoSymbols.length > 0) {
        const { rows } = await client.query(
          `SELECT to_char(month_start,'YYYY-MM') AS ym, symbol, usd_month_avg
             FROM app.crypto_usd_monthly
            WHERE symbol = ANY($1)
              AND month_start BETWEEN $2::date AND $3::date
            ORDER BY month_start`,
          [cryptoSymbols, `${year}-01-01`, `${year}-12-31`]
        );
        for (const r of rows) {
          const ym = r.ym;
          const usdJpy = usdMap[ym];
          if (!usdJpy) continue;
          const jpy = Number(r.usd_month_avg) * usdJpy;
          table[ym] ||= {};
          table[ym][r.symbol.toUpperCase()] = jpy;
        }
      }

      // --- 安全補完：cryptoがtableに無い月は仮値で穴埋め（表示だけ） ---
      for (const sym of ["BTC", "ETH"]) {
        for (let m = 1; m <= 12; m++) {
          const ym = `${year}-${String(m).padStart(2, "0")}`;
          table[ym] ||= {};
          if (table[ym][sym] == null && usdMap[ym]) {
            if (sym === "BTC") table[ym][sym] = 65000 * usdMap[ym];
            if (sym === "ETH") table[ym][sym] = 3500 * usdMap[ym];
          }
        }
      }

      res.json({ base: "JPY", year, mode, table });
    } finally {
      client.release();
    }
  } catch (e) {
    console.error("rates_query_failed", e);
    res.status(500).json({ error: "failed_to_fetch_rates" });
  }
});

/* =========================
 * /api/dashboard/summary （月次サマリ：now/prev）
 * 例）/api/dashboard/summary?month=2025-10&view=total&mode=avg
 * view = total | corporate | personal
 * mode = avg（今はダミーで受け取るだけ）
 * ========================= */
app.get('/api/dashboard/summary', async (req, res) => {
  const month = String(req.query.month || '').trim();   // 'YYYY-MM'
  const view  = String(req.query.view || 'total').trim(); // 'total'|'corporate'|'personal'
  const mode  = String(req.query.mode || 'avg').trim();

  if (!month || !/^\d{4}-\d{2}$/.test(month)) {
    return res.status(400).json({ error: 'month (YYYY-MM) is required' });
  }

  // 資金移動は除外（manual_entry_category.category_name='資金移動'）
  const sql = `
  WITH
  curr_total AS (
  SELECT COALESCE(SUM(
           CASE WHEN m.flow_type='IN'  THEN m.jpy_amount
                WHEN m.flow_type='OUT' THEN -m.jpy_amount END
         ),0) AS total
  FROM app.manual_entry m
  LEFT JOIN app.manual_entry_category c ON c.id = m.category_id
  WHERE to_char(m.trade_date,'YYYY-MM') = $1
    AND m.segment IN (
      'corporate'::app.segment_type,
      'personal'::app.segment_type,
      'corporate_invest'::app.segment_type,
      'personal_invest'::app.segment_type
    )
    AND COALESCE(c.category_name,'') <> '資金移動'
    AND NOT (m.memo LIKE '%削除済み%')
),
prev_total AS (
  SELECT COALESCE(SUM(
           CASE WHEN m.flow_type='IN'  THEN m.jpy_amount
                WHEN m.flow_type='OUT' THEN -m.jpy_amount END
         ),0) AS total
  FROM app.manual_entry m
  LEFT JOIN app.manual_entry_category c ON c.id = m.category_id
  WHERE to_char(m.trade_date,'YYYY-MM') = to_char((to_date($1,'YYYY-MM') - INTERVAL '1 month'),'YYYY-MM')
    AND m.segment IN (
      'corporate'::app.segment_type,
      'personal'::app.segment_type,
      'corporate_invest'::app.segment_type,
      'personal_invest'::app.segment_type
    )
    AND COALESCE(c.category_name,'') <> '資金移動'
    AND NOT (m.memo LIKE '%削除済み%')
),
  curr_corp AS (
  SELECT COALESCE(SUM(CASE WHEN m.flow_type='IN'  THEN m.jpy_amount
                           WHEN m.flow_type='OUT' THEN -m.jpy_amount END),0) AS total
  FROM app.manual_entry m
  LEFT JOIN app.manual_entry_category c ON c.id = m.category_id
  WHERE to_char(m.trade_date,'YYYY-MM') = $1
    AND m.segment IN ('corporate'::app.segment_type, 'corporate_invest'::app.segment_type)
    AND COALESCE(c.category_name,'') <> '資金移動'
    AND NOT (m.memo LIKE '%削除済み%')
),
prev_corp AS (
  SELECT COALESCE(SUM(CASE WHEN m.flow_type='IN'  THEN m.jpy_amount
                           WHEN m.flow_type='OUT' THEN -m.jpy_amount END),0) AS total
  FROM app.manual_entry m
  LEFT JOIN app.manual_entry_category c ON c.id = m.category_id
  WHERE to_char(m.trade_date,'YYYY-MM') = to_char((to_date($1,'YYYY-MM') - INTERVAL '1 month'),'YYYY-MM')
    AND m.segment IN ('corporate'::app.segment_type, 'corporate_invest'::app.segment_type)
    AND COALESCE(c.category_name,'') <> '資金移動'
    AND NOT (m.memo LIKE '%削除済み%')
),
  curr_person AS (
    SELECT COALESCE(SUM(CASE WHEN m.flow_type='IN'  THEN m.jpy_amount
                             WHEN m.flow_type='OUT' THEN -m.jpy_amount END),0) AS total
    FROM app.manual_entry m
    LEFT JOIN app.manual_entry_category c ON c.id = m.category_id
    WHERE to_char(m.trade_date,'YYYY-MM') = $1
      AND m.segment IN ('personal'::app.segment_type, 'personal_invest'::app.segment_type)
      AND COALESCE(c.category_name,'') <> '資金移動'
      AND NOT (m.memo LIKE '%削除済み%')
  ),
  prev_person AS (
    SELECT COALESCE(SUM(CASE WHEN m.flow_type='IN'  THEN m.jpy_amount
                             WHEN m.flow_type='OUT' THEN -m.jpy_amount END),0) AS total
    FROM app.manual_entry m
    LEFT JOIN app.manual_entry_category c ON c.id = m.category_id
    WHERE to_char(m.trade_date,'YYYY-MM') = to_char((to_date($1,'YYYY-MM') - INTERVAL '1 month'),'YYYY-MM')
      AND m.segment IN ('personal'::app.segment_type, 'personal_invest'::app.segment_type)
      AND COALESCE(c.category_name,'') <> '資金移動'
      AND NOT (m.memo LIKE '%削除済み%')
  )
  SELECT
    (SELECT total FROM curr_total)   AS now_total,
    (SELECT total FROM prev_total)   AS prev_total,
    (SELECT total FROM curr_corp)    AS now_corp,
    (SELECT total FROM prev_corp)    AS prev_corp,
    (SELECT total FROM curr_person)  AS now_person,
    (SELECT total FROM prev_person)  AS prev_person
`;

  try {
    const { rows } = await pool.query(sql, [month]);
    const r = rows[0] || {};
    return res.json({
      month,
      rate_mode: mode,
      by_view: {
        total:     { now: Number(r.now_total||0),  prev: Number(r.prev_total||0) },
        corporate: { now: Number(r.now_corp||0),   prev: Number(r.prev_corp||0) },
        personal:  { now: Number(r.now_person||0), prev: Number(r.prev_person||0) },
        unassigned:{ now: Number(r.now_total||0) - Number(r.now_corp||0) - Number(r.now_person||0),
                     prev: Number(r.prev_total||0) - Number(r.prev_corp||0) - Number(r.prev_person||0) }
      }
    });
  } catch (e) {
    console.error('[dashboard/summary] error', e);
    return res.status(500).json({ error: 'dashboard_summary_failed' });
  }
});
/* =========================
 * /api/dashboard/monthly （年次の月別合計）
 * 例）/api/dashboard/monthly?year=2025&view=total&mode=avg
 * ========================= */
app.get('/api/dashboard/monthly', async (req, res) => {
  const year = String(req.query.year || '').trim();
  const view = String(req.query.view || 'total').trim();
  const mode = String(req.query.mode || 'avg').trim();

  if (!year || !/^\d{4}$/.test(year)) {
    return res.status(400).json({ error: 'year (YYYY) is required' });
  }

  // 内側サブクエリ用：alias は me
  const segFilterInner =
  view === 'corporate'
    ? " AND me.segment IN ('corporate'::app.segment_type,'corporate_invest'::app.segment_type) "
  : view === 'personal'
    ? " AND me.segment IN ('personal'::app.segment_type,'personal_invest'::app.segment_type) "
  : " AND me.segment IN ('corporate'::app.segment_type,'personal'::app.segment_type,'corporate_invest'::app.segment_type,'personal_invest'::app.segment_type) ";

  const sql = `
    WITH months AS (
      SELECT generate_series(
        to_date($1||'-01','YYYY-MM'),
        to_date($1||'-12','YYYY-MM'),
        interval '1 month'
      ) AS month_start
    )
    SELECT
      to_char(m.month_start,'YYYY-MM') AS month,
      COALESCE((
        SELECT SUM(CASE WHEN me.flow_type='IN'  THEN me.jpy_amount
                        WHEN me.flow_type='OUT' THEN -me.jpy_amount
                        ELSE 0 END)
          FROM app.manual_entry me
          LEFT JOIN app.manual_entry_category c ON c.id = me.category_id
         WHERE date_trunc('month', me.trade_date) = date_trunc('month', m.month_start)
           ${segFilterInner}
           AND COALESCE(c.category_name,'') <> '資金移動'
AND NOT (me.memo LIKE '%削除済み%')
      ),0) AS 合計
    FROM months m
    ORDER BY month;
  `;

  // ★ 安全な接続パターン（connect→query→release）
  const client = await pool.connect();
  try {
    const { rows } = await client.query(sql, [year]);      // $1 = '2025'
    const normalized = rows.map(r => ({ month: r.month, 合計: Number(r.合計) }));
    return res.json(normalized);
  } catch (e) {
    console.error('[dashboard/monthly] error', e);
    return res.status(500).json({ error: 'dashboard_monthly_failed' });
  } finally {
    client.release();
  }
});

/* =========================
 * GET /api/assets?month=YYYY-MM&view=total|corporate|personal&currency=JPY|USD
 * 口座・ウォレットごとの当月合計（資金移動は除外）
 * ========================= */
app.get('/api/assets', async (req, res) => {
  const month = String(req.query.month || '').trim();     // 'YYYY-MM'
  const view  = String(req.query.view  || 'total').trim();// 'total'|'corporate'|'personal'
  const cur   = String(req.query.currency || 'JPY').trim();

  if (!month || !/^\d{4}-\d{2}$/.test(month)) {
    return res.status(400).json({ error: 'month (YYYY-MM) is required' });
  }

  // 区分フィルタ（invest含む：法人=corporate|corporate_invest、個人=personal|personal_invest）
  const segFilter =
      view === 'corporate'
      ? " AND m.segment IN ('corporate'::app.segment_type,'corporate_invest'::app.segment_type) "
      : view === 'personal'
      ? " AND m.segment IN ('personal'::app.segment_type,'personal_invest'::app.segment_type) "
      : " AND m.segment IN ('corporate'::app.segment_type,'personal'::app.segment_type,'corporate_invest'::app.segment_type,'personal_invest'::app.segment_type) ";

  // 当月のUSD/JPY（通貨表示用換算にのみ使用。集計は常にJPY）
  const sql = `
    WITH base AS (
      SELECT m.account_name,
             m.segment,
             m.flow_type,
             m.jpy_amount,
             m.trade_date
        FROM app.manual_entry m
   LEFT JOIN app.manual_entry_category c ON c.id = m.category_id
       WHERE to_char(m.trade_date,'YYYY-MM') = $1
         ${segFilter}
         AND COALESCE(c.category_name,'') <> '資金移動'
    ),
    agg AS (
      SELECT account_name,
             -- segment は表示用（代表値）。同一口座で混在する場合は最頻値にしたいが、まずは最大件数の方を採用
             mode() within group (order by segment) AS segment,
             sum(CASE WHEN flow_type='IN'  THEN jpy_amount
                      WHEN flow_type='OUT' THEN -jpy_amount
                      ELSE 0 END) AS total_jpy,
             count(*) AS cnt,
             max(trade_date) AS last_date
        FROM base
    GROUP BY account_name
    )
    SELECT
      a.account_name,
      a.segment,
      a.total_jpy::numeric AS total_jpy,
      a.cnt,
      a.last_date::date AS last_date
    FROM agg a
    ORDER BY a.total_jpy DESC, a.account_name;
  `;

  const client = await pool.connect();
  try {
    const { rows } = await client.query(sql, [month]); // $1 = 'YYYY-MM'

    // 表示用に通貨換算
    let usdJpy = 1;
    if (cur === 'USD') {
      const q = `
        SELECT rate_month_avg
          FROM app.fx_rate_monthly
         WHERE currency='USD'
           AND to_char(month_start,'YYYY-MM')=$1
         LIMIT 1`;
      const r2 = await client.query(q, [month]);
      usdJpy = Number(r2.rows?.[0]?.rate_month_avg ?? 1) || 1;
    }

    const mapped = rows.map(r => {
      const jpy = Number(r.total_jpy || 0);
      const display = (cur === 'USD') ? (jpy / usdJpy) : jpy;
      return {
        account_name: r.account_name,
        segment: r.segment,
        cnt: Number(r.cnt || 0),
        last_date: r.last_date,
        total_jpy: jpy,
        total_display: display
      };
    });

    return res.json({ month, view, currency: cur, rows: mapped });
  } catch (e) {
    console.error('[assets] error', e);
    return res.status(500).json({ error: 'assets_failed' });
  } finally {
    client.release();
  }
});

/* =========================
 * CSV Import / Commit
 * ========================= */
const upload = multer({ storage: multer.memoryStorage() });

app.post(
  "/api/csv-import",
  (req, res, next) => {
    upload.single("file")(req, res, (err) => {
      if (err) return res.status(500).json({ error: err.message });
      next();
    });
  },
  async (req, res) => {
    try {
      if (!req.file) return res.status(400).json({ error: "file is required" });
      const text = req.file.buffer.toString("utf-8");
      const records = parse(text, {
        columns: true,
        skip_empty_lines: true,
        trim: true,
      });

      const localPool = new pg.Pool({
        connectionString: process.env.DATABASE_URL,
        ssl: { rejectUnauthorized: false },
      });
      const client = await localPool.connect();

      const pick = (obj, keys) => {
        for (const k of keys) {
          if (obj[k] !== undefined && obj[k] !== null) {
            const v = String(obj[k]).trim();
            if (v !== "") return v;
          }
        }
        return null;
      };

      const toNum = (v) => {
        if (v == null) return null;
        const s = String(v).normalize("NFKC").trim().replace(/[^\d.-]/g, "");
        return s && /^-?\d+(\.\d+)?$/.test(s) ? Number(s) : null;
      };

      let i = 0;
for (const r of records) {
  i++;

  // ★ 共通ヘルパー
  const pick = (obj, keys) => {
    for (const k of keys) {
      const v = obj?.[k];
      if (v != null && String(v).trim() !== "") return String(v).trim();
    }
    return "";
  };

  // ★ フィールド正規化（多様なCSV列対応）
  const tradeDate        = pick(r, ["trade_date", "date", "csvdate", "\ufeff日付", "日付"]) || null;
  const accountName      = pick(r, ["account_name", "account", "口座・ウォレット名"]) || null;
  const flowType         = (pick(r, ["flow_type", "type", "タイプ"]) || "IN").toUpperCase();
  const categoryName     = pick(r, ["category_name", "category", "カテゴリ1", "カテゴリ"]) || null;
  const amountNum        = toNum(pick(r, ["amount", "金額"]));
  const currencyCode     = (pick(r, ["currency", "curr", "通貨", "\ufeff通貨", "Currency"]) || "").toUpperCase() || null;
  const rateNum          = toNum(pick(r, ["rate", "レート"]));
  const jpyAmountNum     = toNum(pick(r, ["jpy_amount", "円建て金額"]));
  const memoText         = pick(r, ["memo", "内容"]) || null;
  const segmentVal       = pick(r, ["segment", "区分"]) || null;

  await client.query(
    `INSERT INTO staging.csv_import_raw
     (source_file, row_num, trade_date, account_name, flow_type, category_name, amount, currency, rate, jpy_amount, memo, segment)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
    [
      req.file.originalname,
      i,
      tradeDate,
      accountName,
      flowType,
      categoryName,
      amountNum,
      currencyCode,
      rateNum,
      jpyAmountNum,
      memoText,
      segmentVal,
    ]
  );
}

      res.json({ inserted: records.length });
      await client.release();
      await localPool.end();
    } catch (e) {
      console.error("csv_import_failed", e);
      res.status(500).json({ error: e.message });
    }
  }
);

app.post("/api/csv-import/commit", async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    await client.query(`
      WITH usd_rates AS (
        SELECT to_char(month_start,'YYYY-MM') AS ym, rate_month_avg
        FROM app.fx_rate_monthly
        WHERE currency='USD'
      ),
      crypto_rates AS (
        SELECT to_char(c.month_start,'YYYY-MM') AS ym, c.symbol, c.usd_month_avg * f.rate_month_avg AS jpy_rate
        FROM app.crypto_usd_monthly c
        JOIN app.fx_rate_monthly f
          ON f.currency='USD' AND f.month_start=c.month_start
      ),
      src AS (
        SELECT
          s.*,
          md5(
            COALESCE(s.source_file,'') || ':' ||
            COALESCE(s.row_num::text,'') || ':' ||
            COALESCE(s.trade_date::text,'') || ':' ||
            COALESCE(s.account_name,'') || ':' ||
            COALESCE(s.flow_type,'') || ':' ||
            COALESCE(s.category_name,'') || ':' ||
            COALESCE(s.amount::text,'') || ':' ||
            COALESCE(s.currency,'') || ':' ||
            COALESCE(s.rate::text,'') || ':' ||
            COALESCE(s.jpy_amount::text,'') || ':' ||
            COALESCE(s.memo,'') || ':' ||
            COALESCE(s.segment,'')
          ) AS shash
        FROM staging.csv_import_raw s
        WHERE
          btrim(replace(s.trade_date::text,'　','')) <> ''
          AND replace(s.trade_date::text,'/','-') ~ '^[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}$'
      ),
      src_dedup AS (
        SELECT DISTINCT ON (shash) *
        FROM src
        ORDER BY shash, row_num
      )
      INSERT INTO app.manual_entry
        (trade_date, account_name, flow_type, category_id, category2_name,
         amount, currency, rate, jpy_amount, memo, source, source_hash, segment)
      SELECT
        to_date(replace(sd.trade_date::text,'/','-'),'YYYY-FMMM-FMDD') AS trade_date,
        COALESCE(sd.account_name,'') AS account_name,
        UPPER(COALESCE(sd.flow_type,'')) AS flow_type,
        NULL AS category_id,
        COALESCE(sd.category_name,'') AS category2_name,
        COALESCE(sd.amount,0) AS amount,

        CASE
          WHEN sd.currency IS NULL OR btrim(sd.currency)='' THEN 'JPY'
          WHEN upper(replace(btrim(sd.currency),'　','')) IN ('円','YEN','JPN') THEN 'JPY'
          WHEN upper(replace(btrim(sd.currency),'　','')) IN ('NT$','NTD','TWD') THEN 'TWD'
          WHEN upper(replace(btrim(sd.currency),'　','')) IN ('WBTC','XBT') THEN 'BTC'
          ELSE upper(replace(btrim(sd.currency),'　',''))
        END AS currency,

        /* レート（CSV > 月平均） */
        COALESCE(
          CASE
            WHEN upper(trim(replace(sd.currency,'　',''))) IN ('BTC','ETH','WBTC','XBT') THEN (
              SELECT jpy_rate FROM crypto_rates
               WHERE symbol = CASE
                                WHEN upper(trim(replace(sd.currency,'　',''))) IN ('WBTC','XBT') THEN 'BTC'
                                ELSE upper(trim(replace(sd.currency,'　','')))
                              END
                 AND ym = to_char(to_date(replace(sd.trade_date::text,'/','-'),'YYYY-FMMM-FMDD'),'YYYY-MM')
            )
            ELSE NULL
          END,
          CASE
            WHEN NULLIF(regexp_replace(sd.rate::text, '[^0-9.+-]', '', 'g'), '') IS NOT NULL
            THEN NULLIF(regexp_replace(sd.rate::text, '[^0-9.+-]', '', 'g'), '')::numeric
            ELSE NULL
          END,
          CASE
            WHEN upper(trim(replace(sd.currency,'　',''))) IN ('JPY','円','YEN','JPN') THEN 1
            WHEN upper(trim(replace(sd.currency,'　',''))) IN ('USD','USDT','USDC') THEN (
              SELECT rate_month_avg FROM usd_rates
               WHERE ym = to_char(to_date(replace(sd.trade_date::text,'/','-'),'YYYY-FMMM-FMDD'),'YYYY-MM')
            )
            ELSE COALESCE((
              SELECT rate_month_avg
                FROM app.fx_rate_monthly
               WHERE currency = CASE
                                  WHEN upper(trim(replace(sd.currency,'　',''))) IN ('NT$','NTD','TWD') THEN 'TWD'
                                  WHEN upper(trim(replace(sd.currency,'　',''))) IN ('JPY','円','YEN','JPN') THEN 'JPY'
                                  ELSE upper(trim(replace(sd.currency,'　','')))
                                END
                 AND to_char(month_start,'YYYY-MM')
                     = to_char(to_date(replace(sd.trade_date::text,'/','-'),'YYYY-FMMM-FMDD'),'YYYY-MM')
               LIMIT 1
            ), 1)
          END
        ) AS rate,

        /* 円換算（確定保存） */
        COALESCE(
          CASE
            WHEN sd.jpy_amount IS NULL OR btrim(replace(sd.jpy_amount::text,'　','')) = '' THEN NULL
            ELSE sd.jpy_amount::numeric
          END,
          (
            COALESCE(sd.amount,0) *
            COALESCE(
              CASE
                WHEN NULLIF(regexp_replace(sd.rate::text, '[^0-9.+-]', '', 'g'), '') IS NOT NULL
                THEN NULLIF(regexp_replace(sd.rate::text, '[^0-9.+-]', '', 'g'), '')::numeric
                ELSE NULL
              END,
              CASE
                WHEN upper(trim(replace(sd.currency,'　',''))) IN ('JPY','円','YEN','JPN') THEN 1
                WHEN upper(trim(replace(sd.currency,'　',''))) IN ('USD','USDT','USDC') THEN (
                  SELECT rate_month_avg FROM usd_rates
                   WHERE ym = to_char(to_date(replace(sd.trade_date::text,'/','-'),'YYYY-FMMM-FMDD'),'YYYY-MM')
                )
                WHEN upper(trim(replace(sd.currency,'　',''))) IN ('BTC','ETH','WBTC','XBT') THEN (
                  SELECT jpy_rate FROM crypto_rates
                   WHERE symbol = CASE
                                    WHEN upper(trim(replace(sd.currency,'　',''))) IN ('WBTC','XBT') THEN 'BTC'
                                    ELSE upper(trim(replace(sd.currency,'　','')))
                                  END
                     AND ym = to_char(to_date(replace(sd.trade_date::text,'/','-'),'YYYY-FMMM-FMDD'),'YYYY-MM')
                )
                ELSE COALESCE((
                  SELECT rate_month_avg
                    FROM app.fx_rate_monthly
                   WHERE currency = CASE
                                      WHEN upper(trim(replace(sd.currency,'　',''))) IN ('NT$','NTD','TWD') THEN 'TWD'
                                      WHEN upper(trim(replace(sd.currency,'　',''))) IN ('JPY','円','YEN','JPN') THEN 'JPY'
                                      ELSE upper(trim(replace(sd.currency,'　','')))
                                    END
                     AND to_char(month_start,'YYYY-MM')
                         = to_char(to_date(replace(sd.trade_date::text,'/','-'),'YYYY-FMMM-FMDD'),'YYYY-MM')
                   LIMIT 1
                ), 1)
              END
            )
          )
        , 0) AS jpy_amount,

        COALESCE(sd.memo,'') AS memo,
        'csv' AS source,
        sd.shash AS source_hash,
        CASE sd.segment
  WHEN '法人資産' THEN 'corporate'
  WHEN '個人資産' THEN 'personal'
  WHEN '法人投資' THEN 'corporate_invest'
  WHEN '個人投資' THEN 'personal_invest'
  ELSE NULL
END::app.segment_type AS segment
      FROM src_dedup sd
      ON CONFLICT (source_hash) DO UPDATE SET
        trade_date=EXCLUDED.trade_date,
        account_name=EXCLUDED.account_name,
        flow_type=EXCLUDED.flow_type,
        category2_name=EXCLUDED.category2_name,
        amount=EXCLUDED.amount,
        currency=EXCLUDED.currency,
        rate=EXCLUDED.rate,
        jpy_amount=EXCLUDED.jpy_amount,
        memo=EXCLUDED.memo,
        source=EXCLUDED.source,
        segment=EXCLUDED.segment;
    `);

    await client.query("DELETE FROM staging.csv_import_raw");
    await client.query("COMMIT");
    res.json({ ok: true });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("[csv-commit]", err.message);
    res.status(500).send("csv_commit_failed");
  } finally {
    client.release();
  }
});

/* =========================
 * POST /api/manual-entry（手入力保存）
 * ========================= */
app.post("/api/manual-entry", async (req, res) => {
  const client = await pool.connect();
  try {
    const body = req.body || {};
    const normStr = (v) => (v ?? "").toString().trim();
    const toNum = (v) => {
      if (v === null || v === undefined || v === "") return null;
      const n = Number(v);
      return Number.isFinite(n) ? n : null;
    };
    // A〜Z 以外（全角・記号・ゼロ幅など）を全除去してから判定
    const normalizeCurrency = (raw) => {
      const s0 = normStr(raw).toUpperCase();
      const s = s0.replace(/[^A-Z]/g, "");
      if (!s) return null;
      if (["JPY", "YEN", "JPN"].includes(s)) return "JPY";
      if (["TWD", "NTD"].includes(s)) return "TWD";
      if (["BTC", "WBTC", "XBT"].includes(s)) return "BTC";
      return s; // 例: AED / USD / IDR / EGP / ETH / USDT / USDC など
    };
    const normalizeFlow = (raw) => {
      const s = normStr(raw).toUpperCase();
      if (s === "IN") return "IN";
      if (s === "OUT") return "OUT";
      if (s === "CF" || s === "CASHFLOW" || s === "キャッシュフロー") return "キャッシュフロー";
      return null;
    };
    const normalizeSegment = (raw) => {
      const s = normStr(raw);
      if (["corporate", "法人資産"].includes(s)) return "corporate";
      if (["personal", "個人資産"].includes(s)) return "personal";
      if (["corporate_invest", "法人投資"].includes(s)) return "corporate_invest";
      if (["personal_invest", "個人投資"].includes(s)) return "personal_invest";
      return null;
    };

    const tradeDate = normStr(body.trade_date);
    const accountName = normStr(body.account_name);
    const flowType = normalizeFlow(body.flow_type);
    const category2Name = normStr(body.category2_name || body.category2 || "");
    const amount = toNum(body.amount);
    const currency = normalizeCurrency(body.currency);
    const rateCsv = toNum(body.rate);
    const memo = normStr(body.memo);
    const segment = normalizeSegment(body.segment);

    // デバッグログ（原因切り分け）
    console.log(
      '[POST/manual-entry] rawCurrency="%s" -> normalized="%s" ym=%s',
      body.currency,
      currency,
      tradeDate?.slice(0, 7)
    );

    if (!tradeDate || !/^\d{4}-\d{2}-\d{2}$/.test(tradeDate))
      return res.status(400).json({ error: "trade_date (YYYY-MM-DD) is required" });
    if (!accountName) return res.status(400).json({ error: "account_name is required" });
    if (!flowType) return res.status(400).json({ error: "flow_type must be IN/OUT/キャッシュフロー" });
    if (amount === null || amount <= 0) return res.status(400).json({ error: "amount must be > 0" });
    if (!currency) return res.status(400).json({ error: "currency is required" });

    const ym = tradeDate.slice(0, 7);
    let rateUsed = rateCsv;

    if (rateUsed === null) {
      if (currency === "BTC" || currency === "ETH") {
        const { rows } = await client.query(
          `SELECT c.usd_month_avg * f.rate_month_avg AS jpy_rate
             FROM app.crypto_usd_monthly c
             JOIN app.fx_rate_monthly f
               ON f.currency='USD' AND to_char(f.month_start,'YYYY-MM')=$1
            WHERE c.symbol=$2 AND to_char(c.month_start,'YYYY-MM')=$1
            LIMIT 1`,
          [ym, currency]
        );
        console.log("[POST/manual-entry] crypto lookup sym=%s ym=%s rows=%d", currency, ym, rows?.length || 0);
        rateUsed = rows?.[0]?.jpy_rate ?? null;
      } else if (currency === "JPY") {
        rateUsed = 1;
      } else if (["USDT", "USDC"].includes(currency)) {
        const { rows } = await client.query(
          `SELECT rate_month_avg FROM app.fx_rate_monthly
            WHERE currency='USD' AND to_char(month_start,'YYYY-MM')=$1 LIMIT 1`,
          [ym]
        );
        console.log("[POST/manual-entry] usd-peg lookup ym=%s rows=%d", ym, rows?.length || 0);
        rateUsed = rows?.[0]?.rate_month_avg ?? null;
      } else {
        const { rows } = await client.query(
          `SELECT rate_month_avg FROM app.fx_rate_monthly
            WHERE currency=$1 AND to_char(month_start,'YYYY-MM')=$2 LIMIT 1`,
          [currency, ym]
        );
        console.log("[POST/manual-entry] fiat lookup cur=%s ym=%s rows=%d", currency, ym, rows?.length || 0);
        rateUsed = rows?.[0]?.rate_month_avg ?? null;
      }
    }

    rateUsed = rateUsed == null ? null : Number(rateUsed);

    if (rateUsed === null || !(Number.isFinite(rateUsed) && rateUsed > 0)) {
      return res.status(400).json({
        error: `rate is missing and monthly average not found for ${currency} in ${ym}`,
      });
    }

    const jpyAmount = Number((amount * rateUsed).toFixed(4));
    const source = "manual";
    const sourceHash = crypto
      .createHash("md5")
      .update(`${source}:${tradeDate}:${accountName}:${flowType}:${amount}:${currency}:${rateUsed}:${memo}`)
      .digest("hex");

        // 冪等INSERT：重複なら既存IDを返し、エラーにしない
const sql = `
  WITH ins AS (
    INSERT INTO app.manual_entry
      (trade_date, account_name, flow_type, category_id, category2_name,
       amount, currency, rate, jpy_amount, memo, source, source_hash, segment)
    VALUES
      ($1,$2,$3, NULL, $4,
       $5, $6, $7, $8, $9, $10, $11, $12)
    ON CONFLICT (source_hash) DO NOTHING
    RETURNING id
  )
  SELECT id, true AS created FROM ins
  UNION ALL
  SELECT id, false AS created
  FROM app.manual_entry
  WHERE source_hash = $11
  ORDER BY created DESC   -- ← 追加：新規があればそれを優先
  LIMIT 1
`;
const params = [
  tradeDate,
  accountName,
  flowType,
  category2Name || null,
  amount,
  currency,
  rateUsed,
  jpyAmount,
  memo || null,
  source,
  sourceHash,
  segment,
];

const q = await client.query(sql, params);
const row = q.rows?.[0];
if (!row) {
  // 念のためのフォールバック（極めてまれなケース）
  return res.status(409).json({ error: "upsert failed: no row returned" });
}
return res.json({
  status: "ok",
  id: String(row.id),
  created: !!row.created, // true=新規作成 / false=既存
  jpy_amount: jpyAmount,
  rate: rateUsed
});
  } catch (e) {
    console.error("manual_entry_insert_failed", e);
    return res.status(400).json({ error: e.message || "insert_failed" });
  } finally {
    client.release();
  }
});

/* =========================
 * PUT /api/manual-entry/:id （既存明細の更新）
 * 使い道：区分（segment）やカテゴリ（category2_name）などの後付け編集
 * ========================= */
// PUT /api/manual-entry/:id
app.put('/api/manual-entry/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // 受け取りうる項目（存在チェックは下でやる）
    const {
      segment,             // corporate/personal/...
      category2_name,      // 「カテゴリ1｜カテゴリ2」の連結（例：銀行口座｜サイト収益）
      amount,              // "2" でも 2 でもOK（numeric(20,8)にキャスト）
      rate,                // 任意："41" など（numeric(20,8)にキャスト）
      memo,                // テキスト
      flow_type            // 任意："IN" / "OUT"
    } = req.body || {};

    const sets = [];
    const vals = [];

    // ヘルパ：安全に SET 句と vals を積み上げ
    const pushSet = (sqlFrag, val) => {
      sets.push(`${sqlFrag}=$${vals.length + 1}`);
      vals.push(val);
    };

    // 1) 文字列は空でなければ更新
    if (segment != null && String(segment) !== '') pushSet('segment', String(segment));
    if (category2_name != null && String(category2_name) !== '') pushSet('category2_name', String(category2_name));
    if (memo != null) pushSet('memo', String(memo));
    if (flow_type === 'IN' || flow_type === 'OUT') pushSet('flow_type', flow_type);

    // 2) 数値系（numericにキャスト）
    const hasAmount = amount != null && String(amount) !== '';
    const hasRate   = rate   != null && String(rate)   !== '';

    if (hasAmount) {
      sets.push(`amount=CAST($${vals.length + 1} AS numeric(20,8))`);
      vals.push(String(amount));
    }
    if (hasRate) {
      sets.push(`rate=CAST($${vals.length + 1} AS numeric(20,8))`);
      vals.push(String(rate));
    }

    // 3) jpy_amount は列演算で再計算（パラメータ不要・順序依存）
    if (hasAmount || hasRate) {
      // 直前で amount/rate を更新していれば、その新値で * 即時計算 *
      sets.push(`jpy_amount = CAST(amount * rate AS numeric(20,4))`);
    }

    if (sets.length === 0) {
      return res.status(400).json({ error: 'No fields to update' });
    }

    vals.push(id);
    const sql = `
      UPDATE app.manual_entry
         SET ${sets.join(', ') }
       WHERE id = $${vals.length}
       RETURNING *;
    `;

    const result = await pool.query(sql, vals);
    if (result.rowCount === 0) {
      return res.status(404).json({ error: 'Not found' });
    }
    res.json({ status: 'ok', row: result.rows[0] });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});
/* =========================
 * /api/manual-entry（GET）
 * ========================= */
app.get("/api/manual-entry", async (req, res) => {
  try {
    const month = String(req.query.month ?? "").trim(); // YYYY-MM
    const segment = String(req.query.segment ?? "total").trim();
    const currency = String(req.query.currency ?? "ALL").trim();
    const excludeTransfer = String(req.query.exclude_transfer ?? "true") === "true";

    if (!month) {
      return res.status(400).json({ error: "month param required (YYYY-MM)" });
    }

    const params = [`${month}-01`, segment, currency, excludeTransfer];

    const listSql = `
      SELECT
        m.id,
        m.trade_date AS date,
        m.account_name AS account,
        m.flow_type AS type,
        m.category_id,
        split_part(COALESCE(m.category2_name,''),'｜',1) AS category_name,
        NULLIF(split_part(COALESCE(m.category2_name,''),'｜',2),'') AS category2_name,
        m.amount,
        m.currency,
        m.rate,
        m.jpy_amount,
        m.memo,
        m.segment
      FROM app.manual_entry m
      LEFT JOIN app.manual_entry_category c ON c.id = m.category_id
      WHERE date_trunc('month', m.trade_date + interval '9 hour') = $1::date
        AND ($2 = 'total' OR m.segment = $2::app.segment_type)
        AND ($3 = 'ALL' OR m.currency = $3)
        AND (CASE WHEN $4 THEN COALESCE(c.category_name,'') <> '資金移動' ELSE TRUE END)
      ORDER BY m.trade_date, m.id
    `;

    const sqlSummary = `
      WITH params AS (
        SELECT
          ($1)::date AS m,
          $2::text   AS seg,
          $3::text   AS cur,
          $4::boolean AS ex
      ),
      curr AS (
        SELECT
          COALESCE(SUM(CASE WHEN m.flow_type='IN'  THEN m.jpy_amount END),0) AS in_jpy,
          COALESCE(SUM(CASE WHEN m.flow_type='OUT' THEN m.jpy_amount END),0) AS out_jpy
        FROM app.manual_entry m
        LEFT JOIN app.manual_entry_category c ON c.id = m.category_id, params p
        WHERE date_trunc('month', m.trade_date) = date_trunc('month', p.m)
          AND (p.seg = 'total' OR m.segment = p.seg::app.segment_type)
          AND (p.cur = 'ALL' OR m.currency = p.cur)
          AND (CASE WHEN p.ex THEN COALESCE(c.category_name,'') <> '資金移動' ELSE TRUE END)
      ),
      prev AS (
        SELECT
          COALESCE(SUM(CASE WHEN m.flow_type='IN'  THEN m.jpy_amount END),0) AS in_jpy,
          COALESCE(SUM(CASE WHEN m.flow_type='OUT' THEN m.jpy_amount END),0) AS out_jpy
        FROM app.manual_entry m
        LEFT JOIN app.manual_entry_category c ON c.id = m.category_id, params p
        WHERE date_trunc('month', m.trade_date) = date_trunc('month', p.m - INTERVAL '1 month')
          AND (p.seg = 'total' OR m.segment = p.seg::app.segment_type)
          AND (p.cur = 'ALL' OR m.currency = p.cur)
          AND (CASE WHEN p.ex THEN COALESCE(c.category_name,'') <> '資金移動' ELSE TRUE END)
      )
      SELECT
        curr.in_jpy AS in_jpy,
        curr.out_jpy AS out_jpy,
        (curr.in_jpy - curr.out_jpy) AS total_jpy,
        prev.in_jpy AS prev_in_jpy,
        prev.out_jpy AS prev_out_jpy,
        (prev.in_jpy - prev.out_jpy) AS prev_total_jpy
      FROM curr, prev;
    `;

    const { rows } = await pool.query(listSql, params);
    const { rows: sumRows } = await pool.query(sqlSummary, params);

    const s = sumRows[0] || {
      in_jpy: 0,
      out_jpy: 0,
      total_jpy: 0,
      prev_in_jpy: 0,
      prev_out_jpy: 0,
      prev_total_jpy: 0,
    };

    const summary = {
      in_jpy: Number(s.in_jpy),
      out_jpy: Number(s.out_jpy),
      total_jpy: Number(s.total_jpy ?? Number(s.in_jpy) - Number(s.out_jpy)),
      prev_total_jpy: Number(s.prev_total_jpy),
      mom_diff_jpy:
        Number(s.total_jpy ?? Number(s.in_jpy) - Number(s.out_jpy)) -
        Number(s.prev_total_jpy),
    };

    return res.json({
      month,
      segment,
      currency,
      exclude_transfer: excludeTransfer,
      rows,
      summary,
    });
  } catch (e) {
    console.error("[manual-entry] error:", e);
    return res.status(500).json({ error: "internal" });
  }
});

/* =========================
 * 自動レート取得（全通貨動的対応）
 * ========================= */

/** base=JPY の timeseries を取得して、日次 JPY→各通貨（JPY基準）を返す */
async function fetchFiatDailyJpyBase(ym, symbols /* ['USD','AED','TWD','IDR','EGP', ...] */) {
  const { start, end } = monthRange(ym);
  const fmt = (d) => d.toISOString().slice(0, 10);
  const url = `https://api.exchangerate.host/timeseries?base=JPY&symbols=${symbols.join(",")}&start_date=${fmt(start)}&end_date=${fmt(end)}`;
  const r = await fetch(url);
  if (!r.ok) throw new Error(`FX timeseries fetch failed: ${r.status}`);
  const j = await r.json();
  const rates = j.rates || {};
  const days = Object.keys(rates).sort();

  const map = {};
  for (const c of symbols) map[c] = [];
  for (const d of days) {
    const row = rates[d] || {};
    for (const c of symbols) {
      const v = Number(row[c]);
      if (Number.isFinite(v) && v > 0) map[c].push(v);
    }
  }
  const avgMap = {};
  for (const c of symbols) {
    const arr = map[c];
    avgMap[c] = arr && arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : null;
  }
  return avgMap; // 例: { USD: 0.0067, AED: 0.024..., ... } (JPY基準)
}

/** 月平均を fx_rate_monthly に JPY/1通貨(=逆数) でUPsert */
async function upsertFiatMonthAverages(ym, symbols) {
  if (!symbols || symbols.length === 0) return { ym, ok: true, upserted: [] };

  const avgJpyBase = await fetchFiatDailyJpyBase(ym, symbols); // 例: { USD: 0.0067, AED: 0.024... } (JPY基準)
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const upserted = [];
    for (const ccy of symbols) {
      const vJpyBase = avgJpyBase[ccy];
      if (!Number.isFinite(vJpyBase) || vJpyBase <= 0) continue;
      const jpyPerUnit = 1 / vJpyBase; // JPY/1通貨 に反転
      await client.query(
        `INSERT INTO app.fx_rate_monthly (currency, month_start, rate_month_avg, rate_ttm)
         VALUES ($1, $2::date, $3::numeric, $3::numeric)
         ON CONFLICT (currency, month_start)
         DO UPDATE SET rate_month_avg = EXCLUDED.rate_month_avg, rate_ttm = EXCLUDED.rate_ttm`,
        [ccy, `${ym}-01`, jpyPerUnit]
      );
      upserted.push(ccy);
    }
    await client.query("COMMIT");
    return { ym, ok: true, upserted };
  } catch (e) {
    await client.query("ROLLBACK");
    console.error("[upsertFiatMonthAverages] failed:", e);
    return { ym, ok: false, error: e.message };
  } finally {
    client.release();
  }
}

/** CoinGecko: 暗号日次USD価格 → 対象月の平均 */
async function fetchCryptoUsdDaily(ym, id) {
  const { start, end } = monthRange(ym);
  const url = `https://api.coingecko.com/api/v3/coins/${id}/market_chart?vs_currency=usd&days=90&interval=daily`;
  const r = await fetch(url, { headers: { accept: "application/json" } });
  if (!r.ok) throw new Error(`CG daily fetch failed: ${id} ${r.status}`);
  const j = await r.json();
  const prices = Array.isArray(j.prices) ? j.prices : [];
  const inMonth = prices
    .map(([ts, price]) => ({ ts: new Date(ts), price: Number(price) }))
    .filter((p) => p.ts >= start && p.ts <= end)
    .map((p) => p.price)
    .filter((n) => Number.isFinite(n));
  return inMonth;
}

const COINGECKO_IDS = { BTC: "bitcoin", ETH: "ethereum" };

async function upsertCryptoMonthAverages(ym, symbols) {
  if (!symbols || symbols.length === 0) return { ym, ok: true, upserted: [] };
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const upserted = [];
    for (const sym of symbols) {
      const id = COINGECKO_IDS[sym];
      if (!id) {
        console.warn("[sync] unknown crypto symbol", sym);
        continue;
      }
      const d = await fetchCryptoUsdDaily(ym, id);
      const mAvg = avg(d);
      if (mAvg && Number.isFinite(mAvg)) {
        await client.query(
          `INSERT INTO app.crypto_usd_monthly (symbol, month_start, usd_month_avg)
           VALUES ($1, $2::date, $3::numeric)
           ON CONFLICT (symbol, month_start)
           DO UPDATE SET usd_month_avg = EXCLUDED.usd_month_avg`,
          [sym, `${ym}-01`, mAvg]
        );
        upserted.push(sym);
      }
    }
    await client.query("COMMIT");
    return { ym, ok: true, upserted };
  } catch (e) {
    await client.query("ROLLBACK");
    console.error("[upsertCryptoMonthAverages] failed:", e);
    return { ym, ok: false, error: e.message };
  } finally {
    client.release();
  }
}

/** 同期メイン：DBに存在する全通貨を動的判定して月次Upsert */
async function syncMonthRates(ym) {
  const uni = await getCurrencyUniverse(); // { fiat:[...], crypto:[...], pegged_usd:[...] }
  const fiatTargets = uni.fiat.filter((c) => c !== "JPY"); // JPYは不要
  const cryptoTargets = uni.crypto;                         // 例: ['BTC','ETH']

  const rFiat = await upsertFiatMonthAverages(ym, fiatTargets);
  const rCrypto = await upsertCryptoMonthAverages(ym, cryptoTargets);

  return { ym, ok: true, universe: uni, fiat: rFiat, crypto: rCrypto };
}

/** 同期対象月の決め方（?month=YYYY-MM があればその月、無ければ先月＋今月） */
function resolveTargetMonths(qMonth) {
  if (qMonth && /^\d{4}-\d{2}$/.test(qMonth)) return [qMonth];
  const now = new Date();
  const y = now.getUTCFullYear();
  const m = now.getUTCMonth() + 1;
  const ymNow = `${y}-${String(m).padStart(2, "0")}`;
  const prev = new Date(Date.UTC(y, m - 2, 1));
  const ymPrev = `${prev.getUTCFullYear()}-${String(prev.getUTCMonth() + 1).padStart(2, "0")}`;
  return [ymPrev, ymNow];
}

/** 手動トリガー */
app.post("/admin/rates/sync", async (req, res) => {
  try {
    const qMonth = (req.query.month || "").toString().trim();
    const months = resolveTargetMonths(qMonth);
    const results = [];
    for (const ym of months) results.push(await syncMonthRates(ym));
    res.json({ status: "ok", results });
  } catch (e) {
    console.error("[admin/rates/sync] error", e);
    res.status(500).json({ error: e.message || "sync_failed" });
  }
});

/** CRON: 毎日 04:10 JST（= 19:10 UTC）に先月＋今月を同期 */
cron.schedule(
  "10 19 * * *",
  async () => {
    try {
      const months = resolveTargetMonths(null);
      console.log("[CRON] rates sync start", months);
      for (const ym of months) {
        const r = await syncMonthRates(ym);
        console.log("[CRON] sync result", r);
      }
      console.log("[CRON] rates sync done");
    } catch (e) {
      console.error("[CRON] rates sync failed", e);
    }
  },
  { scheduled: true, timezone: "UTC" } // サーバTZがJSTなら 'Asia/Tokyo' に変更可
);

// --- Admin/Health APIs (add before app.listen) ---

// 1) ヘルスチェック（Dashboard / AdminのPingで使用）
app.get('/api/healthz', (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

// 2) 管理者用ユーザー一覧（納品用：本番は実テーブル/VIEWに合わせてクエリを調整）
app.get('/api/admin/users', async (req, res) => {
  try {
    // 例: app.users テーブルを想定。無い場合は実スキーマに合わせて調整してください。
    const sql = `
      SELECT
        id,
        name,
        email,
        role,
        to_char(last_login,'YYYY-MM-DD HH24:MI') AS "lastLogin"
      FROM app.users
      ORDER BY id
    `;
    const { rows } = await pool.query(sql);
    res.json({ rows: rows || [] });
  } catch (e) {
    console.error('[admin/users] error', e);
    res.status(500).json({ error: 'admin users fetch failed' });
  }
});

// === Admin: users CREATE ===
app.post('/api/admin/users', async (req, res) => {
  try {
    const { name, email, role = 'viewer', mfaEnabled = false, active = true } = req.body || {};
    if (!name || !email) return res.status(400).json({ error: 'name/email required' });

    const sql = `
      INSERT INTO app.users (name, email, role, mfa_enabled, active, last_login)
      VALUES ($1, $2, $3, $4, $5, NULL)
      RETURNING
        id, name, email, role,
        mfa_enabled AS "mfaEnabled",
        active,
        to_char(last_login,'YYYY-MM-DD HH24:MI') AS "lastLogin"
    `;
    const { rows } = await pool.query(sql, [name, email, role, !!mfaEnabled, !!active]);
    res.json(rows[0]);
  } catch (e) {
    console.error('[admin/users POST] error', e);
    res.status(500).json({ error: 'admin users create failed' });
  }
});

// === Admin: users UPDATE ===
app.put('/api/admin/users/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { name, email, role, mfaEnabled, active } = req.body || {};
    const sql = `
      UPDATE app.users
      SET
        name        = COALESCE($1, name),
        email       = COALESCE($2, email),
        role        = COALESCE($3, role),
        mfa_enabled = COALESCE($4, mfa_enabled),
        active      = COALESCE($5, active)
      WHERE id = $6
      RETURNING
        id, name, email, role,
        mfa_enabled AS "mfaEnabled",
        active,
        to_char(last_login,'YYYY-MM-DD HH24:MI') AS "lastLogin"
    `;
    const vals = [
      name ?? null,
      email ?? null,
      role ?? null,
      typeof mfaEnabled === 'boolean' ? mfaEnabled : null,
      typeof active === 'boolean' ? active : null,
      id
    ];
    const { rows } = await pool.query(sql, vals);
    if (rows.length === 0) return res.status(404).json({ error: 'not found' });
    res.json(rows[0]);
  } catch (e) {
    console.error('[admin/users PUT] error', e);
    res.status(500).json({ error: 'admin users update failed' });
  }
});

// === Admin: users DELETE ===
app.delete('/api/admin/users/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    await pool.query('DELETE FROM app.users WHERE id=$1', [id]);
    res.json({ ok: true });
  } catch (e) {
    console.error('[admin/users DELETE] error', e);
    res.status(500).json({ error: 'admin users delete failed' });
  }
});

// 3) 管理設定（rateMode / autoAggregation）
//   - 永続化が必要な場合は設定テーブルを作成して、SELECT/UPSERTに置き換えてください。
let adminSettings = { rateMode: 'avg', autoAggregation: true };

app.get('/api/admin/settings', (req, res) => {
  try {
    res.json(adminSettings);
  } catch (e) {
    res.status(500).json({ error: 'settings fetch failed' });
  }
});

app.put('/api/admin/settings', async (req, res) => {
  try {
    const { rateMode, autoAggregation } = req.body || {};
    if (rateMode && ['avg', 'trade', 'ttm'].includes(rateMode)) {
      adminSettings.rateMode = rateMode;
    }
    if (typeof autoAggregation === 'boolean') {
      adminSettings.autoAggregation = autoAggregation;
    }
    // ここでDB永続化する場合はUPSERT等に置換
    res.json(adminSettings);
  } catch (e) {
    res.status(500).json({ error: 'settings update failed' });
  }
});

// --- /Admin/Health APIs end ---

/** 起動 */
app.listen(PORT, () => {
  console.log(`Rates API listening on http://localhost:${PORT} [${BUILD_TAG}]`);
});